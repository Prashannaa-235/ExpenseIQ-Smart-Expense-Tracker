package com.expense;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ExpenseServlet")
public class ExpenseServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("index.html");
            return;
        }

        String action = request.getParameter("action");
        int userId = (int) session.getAttribute("userId");

        if ("add".equals(action)) {
            addExpense(request, response, userId);
        } else if ("delete".equals(action)) {
            deleteExpense(request, response, userId);
        }
    }

    private void addExpense(HttpServletRequest request, HttpServletResponse response, int userId)
            throws IOException {
        String title    = request.getParameter("title");
        String amount   = request.getParameter("amount");
        String category = request.getParameter("category");
        String date     = request.getParameter("expense_date");
        String note     = request.getParameter("note");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO expenses (user_id, title, amount, category, expense_date, note) VALUES (?,?,?,?,?,?)"
            );
            ps.setInt(1, userId);
            ps.setString(2, title);
            ps.setDouble(3, Double.parseDouble(amount));
            ps.setString(4, category);
            ps.setString(5, date);
            ps.setString(6, note);
            ps.executeUpdate();
            response.sendRedirect("dashboard.jsp?success=Expense+added!");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Failed+to+add+expense");
        }
    }

    private void deleteExpense(HttpServletRequest request, HttpServletResponse response, int userId)
            throws IOException {
        int expenseId = Integer.parseInt(request.getParameter("id"));

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM expenses WHERE id=? AND user_id=?"
            );
            ps.setInt(1, expenseId);
            ps.setInt(2, userId);
            ps.executeUpdate();
            response.sendRedirect("dashboard.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Delete+failed");
        }
    }
}
