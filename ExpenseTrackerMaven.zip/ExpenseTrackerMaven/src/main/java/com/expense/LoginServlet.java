package com.expense;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email    = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM users WHERE email=? AND password=?"
            );
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("userId",   rs.getInt("id"));
                session.setAttribute("userName", rs.getString("name"));
                response.sendRedirect("dashboard.jsp");
            } else {
                response.sendRedirect("index.html?error=Invalid+email+or+password");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("index.html?error=Login+failed+please+try+again");
        }
    }
}
