<%@ page import="java.sql.*, com.expense.DBConnection" %>
<%@ page session="true" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("index.html");
        return;
    }
    int userId   = (int) session.getAttribute("userId");
    String uName = (String) session.getAttribute("userName");

    // Build category data for pie chart
    StringBuilder catLabels = new StringBuilder();
    StringBuilder catData   = new StringBuilder();
    StringBuilder monthLabels = new StringBuilder();
    StringBuilder monthData   = new StringBuilder();

    try (Connection conn = DBConnection.getConnection()) {
        // Category totals
        PreparedStatement ps1 = conn.prepareStatement(
            "SELECT category, SUM(amount) AS total FROM expenses WHERE user_id=? GROUP BY category ORDER BY total DESC");
        ps1.setInt(1, userId);
        ResultSet rs1 = ps1.executeQuery();
        boolean first = true;
        while(rs1.next()) {
            if(!first){ catLabels.append(","); catData.append(","); }
            catLabels.append("'").append(rs1.getString("category")).append("'");
            catData.append(rs1.getDouble("total"));
            first = false;
        }

        // Monthly totals (last 6 months)
        PreparedStatement ps2 = conn.prepareStatement(
            "SELECT DATE_FORMAT(expense_date,'%b %Y') AS mo, SUM(amount) AS total " +
            "FROM expenses WHERE user_id=? AND expense_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
            "GROUP BY mo ORDER BY MIN(expense_date)");
        ps2.setInt(1, userId);
        ResultSet rs2 = ps2.executeQuery();
        first = true;
        while(rs2.next()) {
            if(!first){ monthLabels.append(","); monthData.append(","); }
            monthLabels.append("'").append(rs2.getString("mo")).append("'");
            monthData.append(rs2.getDouble("total"));
            first = false;
        }
    } catch(Exception e) { e.printStackTrace(); }
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Analytics — ExpenseIQ</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
  <style>
    *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
    :root {
      --bg:#0a0a0f; --card:#13131a; --border:#1e1e2e;
      --accent:#7c3aed; --accent2:#06b6d4;
      --text:#e2e8f0; --muted:#64748b;
    }
    body { background:var(--bg); color:var(--text); font-family:'DM Sans',sans-serif; min-height:100vh; }
    nav {
      display:flex; align-items:center; justify-content:space-between;
      padding:16px 32px; background:var(--card); border-bottom:1px solid var(--border);
      position:sticky; top:0; z-index:100;
    }
    .nav-logo { font-family:'Syne',sans-serif; font-size:1.4rem; font-weight:800;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
    .nav-links a {
      color:var(--muted); text-decoration:none; font-size:.9rem;
      padding:8px 16px; border-radius:8px; transition:all .2s;
    }
    .nav-links a:hover, .nav-links a.active { background:var(--accent); color:#fff; }
    .logout { color:#ef4444 !important; }
    .nav-user { color:var(--muted); font-size:.9rem; }
    .nav-user span { color:var(--text); font-weight:500; }
    .nav-right { display:flex; align-items:center; gap:16px; }

    .main { max-width:1100px; margin:0 auto; padding:32px 24px; }
    .page-title { font-family:'Syne',sans-serif; font-size:1.6rem; font-weight:800; margin-bottom:24px; }
    .page-title span { background:linear-gradient(135deg,var(--accent),var(--accent2));
      -webkit-background-clip:text; -webkit-text-fill-color:transparent; }

    .charts-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; }
    @media(max-width:700px) { .charts-grid { grid-template-columns:1fr; } }

    .card {
      background:var(--card); border:1px solid var(--border);
      border-radius:16px; padding:24px;
      animation:fadeUp .5s ease both;
    }
    .card:nth-child(2) { animation-delay:.1s; }
    @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    .card h3 { font-family:'Syne',sans-serif; font-size:1rem; font-weight:700; margin-bottom:20px; }

    canvas { max-height: 300px; }
  </style>
</head>
<body>

<nav>
  <div class="nav-logo">ExpenseIQ</div>
  <div class="nav-right">
    <div class="nav-user">Welcome, <span><%= uName %></span></div>
    <div class="nav-links">
      <a href="dashboard.jsp">Dashboard</a>
      <a href="analytics.jsp" class="active">Analytics</a>
      <a href="LogoutServlet" class="logout">Logout</a>
    </div>
  </div>
</nav>

<div class="main">
  <div class="page-title">Spending <span>Analytics</span></div>

  <div class="charts-grid">
    <div class="card">
      <h3>Spending by Category</h3>
      <canvas id="pieChart"></canvas>
    </div>
    <div class="card">
      <h3>Monthly Trend (Last 6 Months)</h3>
      <canvas id="barChart"></canvas>
    </div>
  </div>
</div>

<script>
  const colors = ['#7c3aed','#06b6d4','#10b981','#f59e0b','#ef4444','#ec4899'];

  // PIE CHART
  new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
      labels: [<%= catLabels %>],
      datasets: [{
        data: [<%= catData %>],
        backgroundColor: colors,
        borderColor: '#13131a',
        borderWidth: 3,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { labels: { color: '#e2e8f0', font: { family: 'DM Sans' } } }
      }
    }
  });

  // BAR CHART
  new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
      labels: [<%= monthLabels %>],
      datasets: [{
        label: 'Total Spent (₹)',
        data: [<%= monthData %>],
        backgroundColor: 'rgba(124,58,237,0.7)',
        borderColor: '#7c3aed',
        borderWidth: 2,
        borderRadius: 8,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { labels: { color: '#e2e8f0', font: { family: 'DM Sans' } } }
      },
      scales: {
        x: { ticks: { color: '#64748b' }, grid: { color: '#1e1e2e' } },
        y: { ticks: { color: '#64748b' }, grid: { color: '#1e1e2e' } }
      }
    }
  });
</script>
</body>
</html>
