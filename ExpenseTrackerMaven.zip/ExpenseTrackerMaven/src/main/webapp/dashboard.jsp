<%@ page import="java.sql.*, com.expense.DBConnection" %>
<%@ page session="true" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("index.html");
        return;
    }
    int userId   = (int) session.getAttribute("userId");
    String uName = (String) session.getAttribute("userName");

    String filterCat = request.getParameter("category");
    if (filterCat == null) filterCat = "All";

    double total = 0;
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard — ExpenseIQ</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin:0; padding:0; }
    :root {
      --bg: #0a0a0f; --card: #13131a; --border: #1e1e2e;
      --accent: #7c3aed; --accent2: #06b6d4;
      --text: #e2e8f0; --muted: #64748b;
      --success: #10b981; --error: #ef4444;
    }
    body { background:var(--bg); color:var(--text); font-family:'DM Sans',sans-serif; min-height:100vh; }

    /* NAV */
    nav {
      display:flex; align-items:center; justify-content:space-between;
      padding:16px 32px;
      background:var(--card); border-bottom:1px solid var(--border);
      position:sticky; top:0; z-index:100;
    }
    .nav-logo { font-family:'Syne',sans-serif; font-size:1.4rem; font-weight:800;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
    .nav-right { display:flex; align-items:center; gap:16px; }
    .nav-user { color:var(--muted); font-size:0.9rem; }
    .nav-user span { color:var(--text); font-weight:500; }
    .nav-links a {
      color:var(--muted); text-decoration:none; font-size:0.9rem;
      padding:8px 16px; border-radius:8px; transition:all 0.2s;
    }
    .nav-links a:hover, .nav-links a.active { background:var(--accent); color:#fff; }
    .logout { color:var(--error) !important; }

    /* MAIN */
    .main { max-width:1100px; margin:0 auto; padding:32px 24px; }

    /* STATS */
    .stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin-bottom:28px; }
    .stat-card {
      background:var(--card); border:1px solid var(--border);
      border-radius:14px; padding:20px;
      animation: fadeUp 0.5s ease both;
    }
    .stat-card:nth-child(2){animation-delay:.1s}
    .stat-card:nth-child(3){animation-delay:.2s}
    @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    .stat-label { font-size:0.78rem; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; }
    .stat-value { font-family:'Syne',sans-serif; font-size:1.8rem; font-weight:700; margin-top:6px; }
    .stat-value.purple { color:var(--accent); }
    .stat-value.cyan   { color:var(--accent2); }
    .stat-value.green  { color:var(--success); }

    /* GRID LAYOUT */
    .grid { display:grid; grid-template-columns:340px 1fr; gap:24px; }
    @media(max-width:768px) { .grid { grid-template-columns:1fr; } }

    /* CARDS */
    .card {
      background:var(--card); border:1px solid var(--border);
      border-radius:16px; padding:24px;
    }
    .card h3 { font-family:'Syne',sans-serif; font-size:1rem; font-weight:700; margin-bottom:20px;
      color:var(--text); letter-spacing:.3px; }

    /* FORM */
    .form-group { margin-bottom:14px; }
    label { display:block; font-size:0.78rem; color:var(--muted); margin-bottom:5px;
      text-transform:uppercase; letter-spacing:.5px; }
    input, select, textarea {
      width:100%; padding:10px 14px;
      background:var(--bg); border:1px solid var(--border);
      border-radius:9px; color:var(--text);
      font-family:'DM Sans',sans-serif; font-size:0.9rem;
      outline:none; transition:border-color 0.2s;
    }
    input:focus, select:focus, textarea:focus { border-color:var(--accent); }
    select option { background:var(--card); }
    textarea { resize:vertical; min-height:60px; }
    .btn { width:100%; padding:12px; background:linear-gradient(135deg,var(--accent),#9333ea);
      color:#fff; border:none; border-radius:9px; font-family:'Syne',sans-serif;
      font-size:0.95rem; font-weight:600; cursor:pointer; transition:opacity .2s,transform .15s; }
    .btn:hover { opacity:.9; transform:translateY(-1px); }

    /* FILTER BAR */
    .filter-bar { display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap; }
    .filter-btn {
      padding:6px 16px; border-radius:20px; border:1px solid var(--border);
      background:var(--bg); color:var(--muted); font-size:0.82rem; cursor:pointer;
      text-decoration:none; transition:all .2s;
    }
    .filter-btn:hover, .filter-btn.active { background:var(--accent); color:#fff; border-color:var(--accent); }

    /* TABLE */
    table { width:100%; border-collapse:collapse; }
    th { font-size:0.75rem; color:var(--muted); text-transform:uppercase;
      letter-spacing:.5px; padding:8px 12px; text-align:left;
      border-bottom:1px solid var(--border); }
    td { padding:12px; border-bottom:1px solid rgba(30,30,46,0.6); font-size:0.88rem; vertical-align:middle; }
    tr:last-child td { border-bottom:none; }
    tr:hover td { background:rgba(124,58,237,0.05); }

    .badge {
      display:inline-block; padding:3px 10px; border-radius:20px;
      font-size:0.75rem; font-weight:500;
    }
    .badge-food        { background:rgba(16,185,129,.15); color:#10b981; }
    .badge-transport   { background:rgba(6,182,212,.15);  color:#06b6d4; }
    .badge-entertainment { background:rgba(124,58,237,.15); color:#a78bfa; }
    .badge-education   { background:rgba(245,158,11,.15); color:#fbbf24; }
    .badge-utilities   { background:rgba(239,68,68,.15);  color:#f87171; }
    .badge-other       { background:rgba(100,116,139,.15);color:#94a3b8; }

    .del-btn {
      background:rgba(239,68,68,.1); color:var(--error); border:none;
      padding:5px 12px; border-radius:6px; cursor:pointer; font-size:0.8rem;
      transition:background .2s;
    }
    .del-btn:hover { background:rgba(239,68,68,.25); }

    .amount-cell { font-family:'Syne',sans-serif; font-weight:600; color:var(--accent2); }

    .alert { padding:10px 14px; border-radius:8px; font-size:0.85rem;
      margin-bottom:16px; text-align:center; }
    .alert.success { background:rgba(16,185,129,.15); color:var(--success); border:1px solid rgba(16,185,129,.3); }
    .alert.error   { background:rgba(239,68,68,.15);  color:var(--error);   border:1px solid rgba(239,68,68,.3); }

    .empty { text-align:center; color:var(--muted); padding:40px 0; font-size:.9rem; }
  </style>
</head>
<body>

<nav>
  <div class="nav-logo">ExpenseIQ</div>
  <div class="nav-right">
    <div class="nav-user">Welcome, <span><%= uName %></span></div>
    <div class="nav-links">
      <a href="dashboard.jsp" class="active">Dashboard</a>
      <a href="analytics.jsp">Analytics</a>
      <a href="LogoutServlet" class="logout">Logout</a>
    </div>
  </div>
</nav>

<div class="main">

  <%-- Alert messages --%>
  <% String msg = request.getParameter("success"); String err = request.getParameter("error"); %>
  <% if (msg != null) { %><div class="alert success"><%= msg %></div><% } %>
  <% if (err != null) { %><div class="alert error"><%= err %></div><% } %>

  <%-- STATS --%>
  <%
    double totalMonth = 0; int countMonth = 0; double maxExpense = 0;
    String maxCategory = "—";
    try (Connection sc = DBConnection.getConnection()) {
      PreparedStatement ps = sc.prepareStatement(
        "SELECT SUM(amount), COUNT(*), MAX(amount) FROM expenses WHERE user_id=? AND MONTH(expense_date)=MONTH(CURDATE())");
      ps.setInt(1, userId);
      ResultSet rs = ps.executeQuery();
      if (rs.next()) { totalMonth = rs.getDouble(1); countMonth = rs.getInt(2); maxExpense = rs.getDouble(3); }

      PreparedStatement ps2 = sc.prepareStatement(
        "SELECT category FROM expenses WHERE user_id=? GROUP BY category ORDER BY SUM(amount) DESC LIMIT 1");
      ps2.setInt(1, userId);
      ResultSet rs2 = ps2.executeQuery();
      if (rs2.next()) maxCategory = rs2.getString(1);
    } catch(Exception e) { e.printStackTrace(); }
  %>

  <div class="stats">
    <div class="stat-card">
      <div class="stat-label">This Month Total</div>
      <div class="stat-value purple">₹<%= String.format("%.2f", totalMonth) %></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Transactions</div>
      <div class="stat-value cyan"><%= countMonth %></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Top Category</div>
      <div class="stat-value green"><%= maxCategory %></div>
    </div>
  </div>

  <div class="grid">

    <%-- ADD EXPENSE FORM --%>
    <div class="card">
      <h3>+ Add New Expense</h3>
      <form action="ExpenseServlet" method="post">
        <input type="hidden" name="action" value="add"/>
        <div class="form-group">
          <label>Title</label>
          <input type="text" name="title" placeholder="e.g. Lunch, Netflix" required/>
        </div>
        <div class="form-group">
          <label>Amount (₹)</label>
          <input type="number" name="amount" placeholder="0.00" step="0.01" min="0" required/>
        </div>
        <div class="form-group">
          <label>Category</label>
          <select name="category">
            <option>Food</option>
            <option>Transport</option>
            <option>Entertainment</option>
            <option>Education</option>
            <option>Utilities</option>
            <option>Other</option>
          </select>
        </div>
        <div class="form-group">
          <label>Date</label>
          <input type="date" name="expense_date" required/>
        </div>
        <div class="form-group">
          <label>Note (optional)</label>
          <textarea name="note" placeholder="Any details..."></textarea>
        </div>
        <button type="submit" class="btn">Add Expense</button>
      </form>
    </div>

    <%-- EXPENSE LIST --%>
    <div class="card">
      <h3>Expense History</h3>

      <div class="filter-bar">
        <% String[] cats = {"All","Food","Transport","Entertainment","Education","Utilities","Other"};
           for(String c : cats) { %>
        <a href="dashboard.jsp?category=<%= c %>"
           class="filter-btn <%= c.equals(filterCat) ? "active" : "" %>"><%= c %></a>
        <% } %>
      </div>

      <%
        String sql = "SELECT * FROM expenses WHERE user_id=?";
        if (!"All".equals(filterCat)) sql += " AND category=?";
        sql += " ORDER BY expense_date DESC";

        try (Connection conn = DBConnection.getConnection()) {
          PreparedStatement ps = conn.prepareStatement(sql);
          ps.setInt(1, userId);
          if (!"All".equals(filterCat)) ps.setString(2, filterCat);
          ResultSet rs = ps.executeQuery();

          boolean hasRows = false;
      %>
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Date</th>
            <th>Amount</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
        <%
          while (rs.next()) {
            hasRows = true;
            total += rs.getDouble("amount");
            String cat = rs.getString("category").toLowerCase();
        %>
          <tr>
            <td><%= rs.getString("title") %></td>
            <td><span class="badge badge-<%= cat %>"><%= rs.getString("category") %></span></td>
            <td style="color:var(--muted);font-size:.82rem"><%= rs.getString("expense_date") %></td>
            <td class="amount-cell">₹<%= String.format("%.2f", rs.getDouble("amount")) %></td>
            <td>
              <form action="ExpenseServlet" method="post" style="margin:0">
                <input type="hidden" name="action" value="delete"/>
                <input type="hidden" name="id" value="<%= rs.getInt("id") %>"/>
                <button type="submit" class="del-btn" onclick="return confirm('Delete this expense?')">✕</button>
              </form>
            </td>
          </tr>
        <%
          }
          if (!hasRows) {
        %>
          <tr><td colspan="5" class="empty">No expenses found. Add your first one! 💸</td></tr>
        <% } %>
        </tbody>
      </table>
      <% } catch(Exception e) { e.printStackTrace(); } %>

      <% if (!"All".equals(filterCat) || total > 0) { %>
      <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border);
                  display:flex; justify-content:space-between; align-items:center;">
        <span style="color:var(--muted);font-size:.85rem">Total shown</span>
        <span style="font-family:'Syne',sans-serif; font-size:1.2rem; font-weight:700; color:var(--accent)">
          ₹<%= String.format("%.2f", total) %>
        </span>
      </div>
      <% } %>
    </div>

  </div>
</div>

<script>
  // Set today's date as default
  document.querySelector('input[type="date"]').valueAsDate = new Date();
</script>
</body>
</html>
