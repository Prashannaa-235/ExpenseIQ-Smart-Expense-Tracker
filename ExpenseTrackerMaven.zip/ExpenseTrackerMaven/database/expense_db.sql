-- =============================================
-- SMART EXPENSE TRACKER - DATABASE SETUP
-- Run this in MySQL Workbench or CMD
-- =============================================

CREATE DATABASE IF NOT EXISTS expense_db;
USE expense_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    expense_date DATE NOT NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample data to see the app working immediately
INSERT INTO users (name, email, password) VALUES ('Test User', 'test@gmail.com', 'test123');

INSERT INTO expenses (user_id, title, amount, category, expense_date, note) VALUES
(1, 'Groceries', 850.00, 'Food', CURDATE(), 'Monthly groceries'),
(1, 'Bus Pass', 500.00, 'Transport', CURDATE(), 'Monthly pass'),
(1, 'Netflix', 199.00, 'Entertainment', CURDATE(), 'Subscription'),
(1, 'Books', 650.00, 'Education', CURDATE(), 'Java book'),
(1, 'Electricity Bill', 1200.00, 'Utilities', CURDATE(), 'Monthly bill');

SELECT 'Database setup complete!' AS Status;
